{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "+proj=somerc +lat_0=46.95240555555556 +lon_0=7.439583333333333 +k_0=1 +x_0=600000 +y_0=200000 +ellps=bessel +towgs84=674.4,15.1,405.3,0,0,0,0 +units=m +no_defs",
    "points": 108279,
    "boundingBox": {
        "lx": 84940.86,
        "ly": 446686.63,
        "lz": -1.4000000000000002,
        "ux": 85459.07000000002,
        "uy": 447204.84,
        "uz": 516.810000000021
    },
    "tightBoundingBox": {
        "lx": 84940.86,
        "ly": 446686.63,
        "lz": -1.4000000000000002,
        "ux": 85440.37,
        "uy": 447204.84,
        "uz": 44.910000000000007
    },
    "pointAttributes": "LAZ",
    "spacing": 4.48783016204834,
    "scale": 0.001,
    "hierarchyStepSize": 5
}