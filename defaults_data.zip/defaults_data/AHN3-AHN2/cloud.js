{
    "version": "1.7",
    "octreeDir": "data",
    "projection": "+proj=somerc +lat_0=46.95240555555556 +lon_0=7.439583333333333 +k_0=1 +x_0=600000 +y_0=200000 +ellps=bessel +towgs84=674.4,15.1,405.3,0,0,0,0 +units=m +no_defs",
    "points": 85562,
    "boundingBox": {
        "lx": 84927.91,
        "ly": 446700.25,
        "lz": -2.8970000000000004,
        "ux": 85474.43100000001,
        "uy": 447246.771,
        "uz": 543.6240000000079
    },
    "tightBoundingBox": {
        "lx": 84927.91,
        "ly": 446700.25,
        "lz": -2.8970000000000004,
        "ux": 85383.918,
        "uy": 447246.771,
        "uz": 23.834
    },
    "pointAttributes": "LAZ",
    "spacing": 4.733010768890381,
    "scale": 0.001,
    "hierarchyStepSize": 5
}